package com.example.dbeproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivitySupplier extends AppCompatActivity {
    private Button supplierBtn1;
    private Button supplierBtn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_supplier);
        supplierBtn1=findViewById(R.id.supplier1);
        supplierBtn2=findViewById(R.id.supplier2);
        supplierBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivitySupplier.this,MainActivitySupplier1.class);
                startActivity(intent);
            }
        });
        supplierBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivitySupplier.this,MainActivitySupplier2.class);
                startActivity(intent);
            }
        });
    }
}