package com.example.dbeproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        EditText pid =findViewById(R.id.pid);
        EditText pname =findViewById(R.id.pname);
        EditText price =findViewById(R.id.price);
        EditText shop =findViewById(R.id.shop_name);
        EditText suid =findViewById(R.id.suid);
        EditText sid =findViewById(R.id.sid);
        EditText ram =findViewById(R.id.ram);
        EditText lstorage =findViewById(R.id.lstorge);
        EditText processer =findViewById(R.id.processer);
        EditText sname =findViewById(R.id.s_name);
        EditText wid =findViewById(R.id.wid);
        EditText wname =findViewById(R.id.wname);
        EditText wadd =findViewById(R.id.wadd);
        Button button =findViewById(R.id.submit);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pid1 =pid.getText().toString();
                String pname1 =pname.getText().toString();
                String ram1 =ram.getText().toString();
                String processer1 =processer.getText().toString();
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url ="http://192.168.1.3/laptop/creat.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.equals("Success")){
                                    Toast.makeText(MainActivity_2.this,"Data is added",Toast.LENGTH_SHORT).show();
                                }
                                else Toast.makeText(MainActivity_2.this, response,Toast.LENGTH_LONG).show();
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error",error.getLocalizedMessage());

                    }
                }){
                    protected Map<String, String> getParams(){
                        Map<String, String> paramV = new HashMap<>();
                        paramV.put("pid", pid1);
                        return paramV;
                    }
                };
                queue.add(stringRequest);

            }
        });
    }
}