package com.example.dbeproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivityshop extends AppCompatActivity {
    private Button shopBtn1;
    private Button shopBtn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activityshop);
        shopBtn1=findViewById(R.id.shop1);
        shopBtn2=findViewById(R.id.shop2);
        shopBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivityshop.this,MainActivityShop1.class);
                startActivity(intent);
            }
        });
        shopBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivityshop.this,MainActivityshop2.class);
                startActivity(intent);
            }
        });
    }
}