package com.example.dbeproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivitySupplier1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_supplier1);
        EditText name=findViewById(R.id.show);
        TextView result=findViewById(R.id.result);
        Button button=findViewById(R.id.submit);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pid1 =name.getText().toString();
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url ="http://192.168.180.9/laptop/supplier.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
//                                if(response.equals("Success")){
//                                    Toast.makeText(MainActivity.this,"Data is added",Toast.LENGTH_SHORT).show();
//                                }
//                                else Toast.makeText(MainActivity.this, response,Toast.LENGTH_LONG).show();
                                try {
                                    JSONArray jsonArray=new JSONArray(response);
                                    for(int i=0;i<jsonArray.length();i++){
                                        JSONObject jsonObject= jsonArray.getJSONObject(i);
                                        String suid= jsonObject.getString("suid");
                                        String sname= jsonObject.getString("sname");
                                        String wid= jsonObject.getString("wid");
                                        result.append( "Supplier_id:"+suid+"\nSupplier_name:"+sname+" \nStored_in_warehouse:"+wid+"\nNumber_of_Products:"+i*jsonArray.length()+"\n"+"\n");
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error",error.getLocalizedMessage());

                    }
                }){
                    protected Map<String, String> getParams(){
                        Map<String, String> paramV = new HashMap<>();
                        paramV.put("pid", pid1);
                        return paramV;
                    }
                };
                queue.add(stringRequest);
            }
        });
    }
}