package com.example.dbeproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button shopBtn;
    private Button warehouseBtn;
    private Button supplierBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        shopBtn=findViewById(R.id.shop);
        warehouseBtn=findViewById(R.id.warehouse);
        supplierBtn=findViewById(R.id.supplier);
        shopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,MainActivityshop.class);
                startActivity(intent);
            }
        });
        warehouseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,MainActivityWarehouse.class);
                startActivity(intent);
            }
        });
        supplierBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,MainActivitySupplier.class);
                startActivity(intent);
            }
        });
    }
}