package com.example.dbeproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity_login extends AppCompatActivity {
    EditText username,pass;
    Button b;
    private static String value;
    public static String getValue() {
        return value;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        username = findViewById(R.id.editTextTextEmailAddress);
        pass = findViewById(R.id.editTextTextPassword);
        b = findViewById(R.id.button);
        b.setOnClickListener(
                v -> {
                    if(username.getText().toString().contains("@") && pass.length()>=8)
                    {
                        openActivity2();
                    }
                    else if(!username.getText().toString().contains("@") && pass.length()<8)
                    {
                        Toast.makeText(getApplicationContext(),"Incorrect Username and Password",Toast.LENGTH_SHORT).show();
                    }
                    else if(pass.length()<8)
                    {
                        Toast.makeText(getApplicationContext(),"Incorrect Password",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Incorrect Username",Toast.LENGTH_SHORT).show();
                    }
                });
    }



    public void openActivity2(){
        value = username.getText().toString().trim();
        Intent activity3 = new Intent(this, MainActivity.class);
        startActivity(activity3);
    }


}
