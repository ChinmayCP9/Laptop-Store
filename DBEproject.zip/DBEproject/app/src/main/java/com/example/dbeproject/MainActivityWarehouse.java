package com.example.dbeproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivityWarehouse extends AppCompatActivity {
    private Button warehouseBtn1;
    private Button warehouseBtn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_warehouse);
        warehouseBtn1=findViewById(R.id.warehouse1);
        warehouseBtn2=findViewById(R.id.warehouse2);
        warehouseBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivityWarehouse.this,MainActivityWarehouse1.class);
                startActivity(intent);
            }
        });
        warehouseBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivityWarehouse.this,MainActivityWarehouse2.class);
                startActivity(intent);
            }
        });
    }
}